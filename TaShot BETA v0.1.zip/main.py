from ursina import *
import math
import os
from random import uniform
from pathlib import Path

app = Ursina()

application.asset_folder = Path(os.path.dirname(__file__))

# --------------------------------
# CONFIGURACIÓN VENTANA
# --------------------------------

window.title = 'TaShot BETA v0.1'
window.borderless = False
window.fullscreen = False
window.color = color.rgb(170, 200, 230)

# --------------------------------
# TEXTO DEL JUEGO
# --------------------------------

game_title = Text(
    text='TaShot BETA v0.1',
    position=(0, 0.3),
    scale=2,
    color=color.black,
    origin=(0, 0)
)

# --------------------------------
# MENÚ
# --------------------------------

menu_mode = True
credits_mode = False

play_button = Button(
    text='Jugar',
    position=(0, 0),
    scale=(0.2, 0.1),
    color=color.black,
    on_click=lambda: start_game()
)

credits_button = Button(
    text='Creditos',
    position=(0, -0.2),
    scale=(0.2, 0.1),
    color=color.black,
    on_click=lambda: show_credits()
)

credits_text = Text(
    text='Diseño de codigo - Antón Quinteiro (Antionpin) y Nicolas Figueroa\nDiseño visual - Manuel Cabral y proximamente León Mishka Guigoures',
    position=(0, 0),
    scale=1,
    color=color.black,
    origin=(0, 0),
    enabled=False
)

back_button = Button(
    text='Volver',
    position=(0, -0.4),
    scale=(0.2, 0.1),
    color=color.light_gray,
    on_click=lambda: back_to_menu(),
    enabled=False
)

# --------------------------------
# FUNCIONES DEL MENÚ
# --------------------------------

def start_game():
    global menu_mode
    menu_mode = False
    game_title.enabled = False
    play_button.enabled = False
    credits_button.enabled = False
    credits_text.enabled = False
    back_button.enabled = False

def show_credits():
    global credits_mode
    credits_mode = True
    game_title.enabled = False
    play_button.enabled = False
    credits_button.enabled = False
    credits_text.enabled = True
    back_button.enabled = True

def back_to_menu():
    global credits_mode
    credits_mode = False
    game_title.enabled = True
    play_button.enabled = True
    credits_button.enabled = True
    credits_text.enabled = False
    back_button.enabled = False

Sky()

# --------------------------------
# SUELO
# --------------------------------

ground = Entity(
    model='plane',
    scale=(500, 1, 500),
    texture='Suelos/Up.png',
    texture_scale=(64, 64),
    color=color.rgb(100, 128, 100),
    collider='box'
)

# --------------------------------
# ÁRBOLES RANDOM
# --------------------------------

tree_model_path = 'Objetos/Arbol_Prueba.obj'
base_dir = os.path.dirname(os.path.abspath(__file__))
full_tree_path = os.path.join(base_dir, tree_model_path)

if os.path.exists(full_tree_path):
    model_to_use = tree_model_path
else:
    model_to_use = 'cube'
    print(f"Advertencia: No se encontró {full_tree_path}")

trees = []
for i in range(15):
    x = uniform(-80, 80)
    z = uniform(-80, 80)
    if math.sqrt(x**2 + z**2) < 15:
        x += 15 if x >= 0 else -15
        z += 15 if z >= 0 else -15

    tree = Entity(
        model=model_to_use,
        position=(x, 1, z),
        scale=4,
        rotation_y=uniform(0, 360),
        collider='box',
        collider_scale=(1.2, 1.5, 1.2),
        color=color.green
    )
    trees.append(tree)

# --------------------------------
# LÍNEAS CARRETERA
# --------------------------------

for i in range(40):

    Entity(
        model='cube',
        color=color.yellow,
        scale=(0.5, 0.02, 2),
        position=(0, 0.02, i * 6 - 100)
    )

# --------------------------------
# CUERPO DEL TANQUE
# --------------------------------

cuerpo = Entity(

    model='Tanques/Primer_Tanque_Cuerpo.obj',

    color=color.light_gray,

    scale=0.8,

    position=(0, 0.4, 0),

    collider='box',

    double_sided=True
)

# --------------------------------
# TORRETA + CAÑÓN
# --------------------------------

torreta = Entity(

    parent=cuerpo,

    model='Tanques/Primer_Tanque_Torreta.obj',

    color=color.gray,

    scale=1,

    # AJUSTA SI HACE FALTA
    position=(0, 0, 0),

    double_sided=True
)

# --------------------------------
# PUNTA DEL CAÑÓN
# --------------------------------

punta_canion = Entity(

    parent=torreta,

    model='cube',

    visible=False,

    scale=0.1,

    # AJUSTA ESTO
    position=(0, 0, 3)
)

# --------------------------------
# ILUMINACIÓN
# --------------------------------

DirectionalLight(
    rotation=(45, -45, 0),
    y=10,
    z=-10
)

AmbientLight(
    color=color.rgba(120, 120, 120, 0.6)
)

# --------------------------------
# CÁMARA
# --------------------------------

camera.fov = 75

camera.position = (0, 4, -12)

# --------------------------------
# VARIABLES
# --------------------------------

speed = 12
rotation_speed = 70
mouse_sensitivity = 300
manual_mode = False

# --------------------------------
# UPDATE
# --------------------------------

def update():
    if menu_mode or credits_mode:
        return

    # ----------------------------
    # MOVIMIENTO
    # ----------------------------

    if not manual_mode:
        move_amount = (
            held_keys['w']
            - held_keys['s']
        ) * speed * time.dt

        cuerpo.position += (
            cuerpo.forward
            * move_amount
        )

    # ----------------------------
    # ROTACIÓN CUERPO
    # ----------------------------

    if not manual_mode:
        cuerpo.rotation_y += (
            held_keys['d']
            - held_keys['a']
        ) * rotation_speed * time.dt

    # ----------------------------
    # ROTACIÓN TORRETA
    # ----------------------------

    torreta.rotation_y += (
        mouse.velocity[0]
        * mouse_sensitivity
    )

    # ----------------------------
    # EFECTO MOVIMIENTO
    # ----------------------------

    moving = (
        held_keys['w']
        or held_keys['s']
    ) and not manual_mode

    if moving:

        cuerpo.rotation_z = math.sin(
            time.time() * 8
        ) * 0.5

    else:

        cuerpo.rotation_z = lerp(
            cuerpo.rotation_z,
            0,
            time.dt * 4
        )

    # ----------------------------
    # CÁMARA
    # ----------------------------

    if not manual_mode:
        target_position = (

            cuerpo.position

            - cuerpo.forward * 12

            + Vec3(0, 4, 0)
        )

        camera.position = lerp(

            camera.position,

            target_position,

            time.dt * 5
        )

        camera.look_at(
            cuerpo.position + Vec3(0, 2, 0)
        )

        camera.rotation_z = 0
    else:
        camera.position = cuerpo.position - torreta.forward * 12 + Vec3(0, 4, 0)
        camera.rotation = torreta.world_rotation
        camera.rotation_z = 0

# --------------------------------
# DISPARAR
# --------------------------------

def input(key):

    # CLICK DERECHO
    if key == 'right mouse down':

        bala = Entity(

            model='Balas/Primer_Tanque_Bala.obj',

            color=color.dark_gray,

            scale=0.3,

            position=punta_canion.world_position,

            rotation=torreta.world_rotation,

            collider='box'
        )

        # DIRECCIÓN
        bala.direction = torreta.forward

        # VELOCIDAD
        bala.speed = 40

        # UPDATE BALA
        def bala_update():

            bala.position += (

                bala.direction

                * bala.speed

                * time.dt
            )

            # COLISIÓN CON ÁRBOLES
            hit_info = bala.intersects()
            if hit_info.hit and hit_info.entity in trees:
                destroy(hit_info.entity)
                destroy(bala)
                return

            # DESTRUIR LEJOS
            if distance(
                bala.position,
                cuerpo.position
            ) > 200:

                destroy(bala)

        bala.update = bala_update

    # MODO MANUAL
    if key == 'm':
        global manual_mode
        manual_mode = not manual_mode

    # ENTRAR EN MODO MENU
    if key == 'escape':
        global menu_mode
        menu_mode = True
        game_title.enabled = True
        play_button.enabled = True
        credits_button.enabled = True
        credits_text.enabled = False
        back_button.enabled = False
# --------------------------------
# EJECUTAR
# --------------------------------

app.run()